<?php
/**
 * Wds Basic widgets
 */
use \Elementor\Widget_Base;
class Wds_Basic_widgets extends Widget_Base {



	/**
	 * Get widget name.
	 */
	public function get_name() {
		return 'Wds_Basic_widget';
	}



	/**
	 * Get widget title.
	 */
	public function get_title() {
		return __( 'Basic widget', 'wds_ele_textdomain' );
	}



	/**
	 * Get widget icon.
	 */
	public function get_icon() {
		return 'fa fa-battery-three-quarters';
	}



	/**
	 * Get widget categories.
	 */
	public function get_categories() {
		return [ 'wds-custom-cat' ];
	}


	
	/**add Stylesheet  Dependency in weidget */
	public function get_style_depends(){
		return ["wds-widget-css"]; 
	}



	/**add Javascript Dependency in weidget */
	public function get_script_depends(){  
		return ["wds-custom-js"];
		
	}


	// Registert contorls
//start Content paragraph
	
//End Register control section

//start render

	protected function render(){
		$settings = $this->get_settings_for_display();
		?>




<!-- Simplest Slider -->
<head>
	<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,700">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
</head>
<section>
	<div class="customer-feedback">
		<div class="container text-center">

			<div class="row">
				<div class="col-md-offset-3 col-md-6 col-sm-offset-2 col-sm-8">
					<div class="owl-carousel feedback-slider">

						<!-- slider item -->
						<div class="feedback-slider-item">
							<img src="//c2.staticflickr.com/8/7310/buddyicons/24846422@N06_r.jpg" class="center-block img-circle" alt="Customer Feedback">
							<h3 class="customer-name">Lisa Redfern</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It is a long established fact that a reader will be distracted by the readable its layout.</p>
							<span class="light-bg customer-rating" data-rating="5">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->

						<!-- slider item -->
						<div class="feedback-slider-item">
							<img src="https://res.cloudinary.com/hnmqik4yn/image/upload/c_fill,fl_force_strip,h_128,q_100,w_128/v1493982718/ah57hnfnwxkmsciwivve.jpg" class="center-block img-circle" alt="Customer Feedback">
							<h3 class="customer-name">Cassi</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It is a long established fact that a reader will be distracted by the readable its layout.</p>
							<span class="light-bg customer-rating" data-rating="4">
								4
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->

						<!-- slider item -->
						<div class="feedback-slider-item">
							<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/451270/profile/profile-80.jpg" class="center-block img-circle" alt="Customer Feedback">
							<h3 class="customer-name">Md Nahidul</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. It is a long established fact that a reader will be distracted by the readable its layout.</p>
							<span class="light-bg customer-rating" data-rating="5">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>
						<!-- /slider item -->
						
					</div><!-- /End feedback-slider -->

					<!-- side thumbnail -->
					<div class="feedback-slider-thumb hidden-xs">
						<div class="thumb-prev">
							<span>
								<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/451270/profile/profile-80.jpg" alt="Customer Feedback">
							</span>
							<span class="light-bg customer-rating">
								5
								<i class="fa fa-star"></i>
							</span>
						</div>

						<div class="thumb-next">
							<span>
								<img src="https://res.cloudinary.com/hnmqik4yn/image/upload/c_fill,fl_force_strip,h_128,q_100,w_128/v1493982718/ah57hnfnwxkmsciwivve.jpg" alt="Customer Feedback">
							</span>
							<span class="light-bg customer-rating">
								4
								<i class="fa fa-star"></i>
							</span>
						</div>
					</div>
					<!-- /side thumbnail -->

				</div><!-- /End col -->
			</div><!-- /End row -->
		</div><!-- /End container -->
	</div><!-- /End customer-feedback -->
</section>

<!-- extra -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script> 


<?php

		
	}






}